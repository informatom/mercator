class AssetsController < ApplicationController

  def index
  end
end